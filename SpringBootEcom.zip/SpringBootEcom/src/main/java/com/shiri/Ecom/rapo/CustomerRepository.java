package com.shiri.Ecom.rapo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shiri.Ecom.model.Customer;

public interface CustomerRepository  extends JpaRepository<Customer, Long>{

	Customer findByEmailAndPassword(String email, String password);

}